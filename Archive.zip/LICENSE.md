This project is licensed by GPL version 2.1.
Also under The LaTeX Project Public Li­cense.

